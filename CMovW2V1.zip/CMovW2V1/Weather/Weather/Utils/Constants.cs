﻿namespace Weather
{
    public static class Constants
    {
        public const string OpenWeatherMapEndpoint = "https://api.openweathermap.org/data/2.5/";
        public const string OpenWeatherMapAPIKey = "060f2c6ce671402a809c714ced30438b";
    }
}
